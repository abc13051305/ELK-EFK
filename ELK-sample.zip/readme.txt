1.請先確定docker network有叫做elk的網路

2.rabbitmq-cluster-docker這一包是三台rabbitmq集群，請在使用docker-elk-rabbitmq和elk-cluster這兩包前先啟動rabbitmq-cluster-docker這一包

3.初始化:在最開始使用前，要先進行初始化，預先建立好後續elk需要使用的帳戶
	docker compose up setup
	
4.啟動指令:
	沒有beat:
		docker compose up 
	metricbeat: 
		docker compose -f docker-compose.yml -f extension/metricbeat/metricbeat-compose.yml up
	heartbeat:
		docker compose -f docker-compose.yml -f extension/heartbeat/heartbeat-compose.yml up

	
5.四包都有三種log來源
	a.nginx:訪問http://IP:8787/
	b.http:發送帶有json格是內容例如:curl -X POST -H "Content-Type: application/json" -d '{"name": "John", "age": 30}' http://IP:8888
	c.log發送日誌到/tmp/output/mockservice.log，logstash讀取這個file，
	測試方式，先java -jar ServiceMockProject-0.0.5-SNAPSHOT.jar
	再 curl http://IP:32145/genLogs/json/<給一個要發送的筆數>